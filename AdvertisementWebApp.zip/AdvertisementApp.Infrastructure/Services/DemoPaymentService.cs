﻿namespace AdvertisementApp.BusinessLogic.Services
{
    public class DemoPaymentService : IPaymentService
    {
        public bool PaySubscription(string userName, int price)
        {
            var success = true;
            return success;
        }
    }
}
