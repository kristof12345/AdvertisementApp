﻿namespace AdvertisementApp.DataBase
{
    public class DatabaseSettings
    {
        public string ConnectionString { get; set; }
    }
}
