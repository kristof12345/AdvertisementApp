﻿using AdvertisementApp.BusinessLogic.Models.Subscriptions;

namespace AdvertisementApp.BusinessLogic.Models.UserRequests
{
    public class SubscriptionRequest
    {
        public SubscriptionModel Subscription { get; set; }
    }
}
