﻿namespace AdvertisementApp.BusinessLogic.Models.Users
{
    public enum UserStatus
    {
        Enabled,
        Disabled
    }
}
