﻿namespace AdvertisementApp.BusinessLogic.Models.Users
{
    public enum UserType
    {
        User,
        Administrator
    }
}
