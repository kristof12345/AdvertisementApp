﻿namespace AdvertisementApp.BusinessLogic.Models.Subscriptions
{
    public class SubscriptionResult
    {
        public bool Success { get; set; }
        public Subscription Subscription { get; set; }
    }
}
