﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdvertisementApp.BusinessLogic.Models
{
    public class Range
    {
        public int From { get; set; } = 0;
        public int To { get; set; } = 100;
    }
}
