﻿using AdvertisementApp.BusinessLogic.Repositories;
using AdvertisementApp.BusinessLogic.Services;
using AdvertisementApp.DataBase.Context;
using AdvertisementApp.DataBase.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics;

namespace AdvertisementApp.SubscriptionManager
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

        }
    }
}
