class User {
  userName: string = "";
  phoneNumber: string = "";
  email: string = "";
}

export default User;
