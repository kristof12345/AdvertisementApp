export interface ErrorModel {
  type: string;
  code: string;
  description: string;
}
