export interface Cursor{
    from: number;
    to: number;
}