export interface AppSettings {
    title: string;
    subtitle: string;
}