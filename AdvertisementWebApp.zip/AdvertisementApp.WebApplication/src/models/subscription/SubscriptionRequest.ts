import { SubscriptionModel } from "./Subscription";

export interface SubscriptionRequest {
  subscription: SubscriptionModel;
}
